# MAX Week 2 — API con Gemini desplegada en Azure

Paquete actualizado para Gemini; sustituye los archivos de la versión anterior con Groq.

Esta guía resuelve solo el tercer pendiente: recibir un claim y devolver un resumen generado por un LLM. El alojamiento es Azure App Service F1; el LLM se consume a través de Gemini Developer API, Free tier. No usa Azure OpenAI. Primera versión: el cliente envía el claim completo en JSON; no hay búsqueda por ID en Databricks. Usar únicamente datos sintéticos.

## Stack y archivos

| Parte | Stack | Ubicación |
|---|---|---|
| Desarrollo | GitHub Codespaces | Repositorio max1102-pipeline |
| API, validación y llamada al LLM | Python, FastAPI, Pydantic, Google Gen AI SDK | api/main.py |
| Dependencias | pip | api/requirements.txt |
| Claves locales | Variables de entorno | api/.env, fuera de Git |
| Modelo | Gemini Developer API, Free tier: gemini-2.5-flash-lite | Servicio externo |
| Alojamiento | Azure App Service, Linux, F1 | Azure Portal |
| Publicación | Azure CLI, ZIP deploy | Terminal de Codespaces |

Los valores recibidos se validan. El prompt incluye únicamente monto, estado y fecha. El claim_id se devuelve al cliente, pero no se envía al LLM. Esto no certifica anonimización ni cumplimiento para datos reales. Las instrucciones al modelo reducen errores; revisa que el resumen conserve los valores. El endpoint no predice readmisión ni toma decisiones clínicas.

## 1. Crear o elegir tu suscripción — Azure web

Entra en https://portal.azure.com. Usa Azure for Students solo si eres elegible y Microsoft verifica tu condición académica. Alternativa: Azure Free Account, para nuevos usuarios elegibles, con $200 por hasta 30 días y tarjeta de verificación. No cambies a pago por uso para esta prueba. Azure for Students ofrece $100 por hasta 12 meses sin tarjeta a estudiantes elegibles.

Comprueba el nombre de la suscripción en Subscriptions/Suscripciones. La prueba normal deshabilita los servicios al vencer o agotarse el crédito si no aceptas pasar a pago por uso. F1 es alojamiento gratuito limitado: 60 minutos de CPU por día, no una hora de reloj de funcionamiento. No tiene SLA ni se recomienda para producción.

## 2. Obtener la clave del LLM — Google AI Studio, web

Abre https://aistudio.google.com/apikey e inicia sesión con tu cuenta de Google. Acepta los términos. En API Keys, pulsa Create API key y elige crear un proyecto nuevo si aparece esa opción, o el proyecto predeterminado que AI Studio haya creado para ti. Puedes llamarlo max-week2-gemini.

Confirma que el proyecto muestre Free tier. No pulses Set up billing ni vincules un proyecto con facturación habilitada para esta práctica gratuita. Copia la clave y guárdala en privado; no la subas a GitHub ni la envíes por chat.

Usaremos gemini-2.5-flash-lite. Su API de texto estándar tiene nivel gratuito en la página oficial de precios consultada; comprueba las cuotas efectivas de tu proyecto en AI Studio. No es uso ilimitado. El nivel gratuito puede utilizar entradas y salidas para mejorar productos: usa solamente claims sintéticos.

## 3. Copiar los archivos — Codespaces, explorador

Abre tu Codespace del repositorio max1102-pipeline. Descarga nuevamente MAX_Week2_Azure_API.zip desde la respuesta actual; ahora contiene Gemini. Súbelo a la raíz del explorador de Codespaces (Upload o arrastrar el archivo desde tu equipo). Debe quedar junto a airflow/, data/ y databricks/. Usa el nombre exacto del ZIP; el navegador puede añadir un número a una descarga repetida.

Terminal de Codespaces:

```bash
cd /workspaces/max1102-pipeline
unzip -o MAX_Week2_Azure_API.zip
ls api
```

Si tu ruta difiere, utiliza la raíz real de tu repositorio. Debes ver main.py, requirements.txt, .env.example, test_api.py y requirements-dev.txt. El ZIP no cambia tus notebooks ni archivos de Airflow. El parámetro -o reemplaza los archivos entregados de la API anterior. Si hiciste cambios propios en api/main.py, guarda una copia antes de reemplazarlo. El ZIP no contiene .env: tus claves locales no se reemplazan.

## 4. Comprobar .gitignore — Codespaces, editor

Abre .gitignore en la raíz. Conserva lo que ya contiene y añade únicamente las reglas que falten:

```gitignore
.env
.env.*
!.env.example
.venv/
__pycache__/
*.pyc
.pytest_cache/
*.zip
```

Los archivos .env reales y los entornos virtuales no se guardan en Git. .env.example solo contiene ejemplos sin claves.

## 5. Instalar dependencias — Terminal de Codespaces

```bash
cd /workspaces/max1102-pipeline/api
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

Este entorno instala FastAPI, Uvicorn y google-genai para la API. Si .venv ya existe, puedes reutilizarlo y ejecutar la activación e instalación. Las versiones incluidas se probaron con Python 3.12. No instala nada en el contenedor de Airflow. api/main.py ya contiene todo el código del endpoint; puedes abrirlo para leerlo.

## 6. Crear o actualizar las dos claves locales — Codespaces

Si api/.env ya existe de la guía anterior, conserva APP_API_KEY, elimina GROQ_API_KEY y GROQ_MODEL, y deja las tres variables Gemini mostradas abajo. No basta con cambiar la clave: debes instalar también los archivos actualizados.

Si todavía no tienes .env ni una clave propia, en la terminal, dentro de api/:

```bash
cp -n .env.example .env
python -c 'import secrets; print(secrets.token_urlsafe(32))'
```

El segundo comando genera TU clave de acceso al endpoint. Guárdala en privado. Editor de Codespaces: abre api/.env y reemplaza los ejemplos:

```dotenv
GEMINI_API_KEY=tu_clave_real_de_google_ai_studio
APP_API_KEY=la_clave_aleatoria_que_generaste
GEMINI_MODEL=gemini-2.5-flash-lite
```

GEMINI_API_KEY autoriza tu aplicación ante Gemini. APP_API_KEY autoriza al cliente ante tu API. Son distintas. No uses literalmente los textos de ejemplo.

Comprueba en la terminal:

```bash
git check-ignore -v .env
```

Debe mostrar la regla que excluye .env. Si no aparece, corrige .gitignore antes de guardar código en GitHub. Si una clave ya fue publicada en Git, revócala y genera otra: ignorar el archivo después no retira la clave del historial.

## 7. Probar la API en Codespaces — Terminal y navegador

Terminal, api/ con el entorno activado:

```bash
python -m uvicorn main:app --env-file .env --host 0.0.0.0 --port 8000
```

Déjalo funcionando. Si sigue abierta la API antigua, detén ese proceso con Ctrl+C antes de iniciar la nueva; reinicia Uvicorn cuando cambies .env. Codespaces > Ports > 8000 > Open in Browser. Mantén Private. En la URL abierta, añade /docs. No uses localhost del teléfono: utiliza la dirección reenviada por Codespaces.

En Swagger, comprueba que el título diga Claim Summary con Gemini:

1. Pulsa Authorize.
2. En el campo de X-API-Key pega APP_API_KEY. Pulsa Authorize y Close.
3. Abre POST /claims/llm-summary.
4. Pulsa Try it out, pega este JSON y pulsa Execute:

```json
{
  "claim_id": "CLM-00001",
  "claim_amount": 1250.50,
  "claim_status": "PAID",
  "service_date": "2025-12-10"
}
```

Debes recibir HTTP 200 con claim_id, summary y model. El texto exacto varía. /health devuelve {"status":"ok"}, pero solo verifica el servidor, no el LLM.

## 8. Crear el alojamiento — Azure Portal

Si ya creaste una Web App F1 con la guía anterior, utiliza esa misma aplicación y omite solo esta creación. Sí debes actualizar las variables y volver a desplegar.

Azure Portal > busca App Services > Create/Crear > Web App/Aplicación web. Configura:

| Campo | Valor |
|---|---|
| Subscription | Tu suscripción Students o Free Trial |
| Resource group | Crear nuevo: rg-max-week2-api |
| Name | Un nombre único, por ejemplo maxweek2-gustavo-58341 |
| Publish | Code/Código |
| Runtime stack | Python 3.12 |
| Operating system | Linux |
| Region | Una región permitida que ofrezca F1; prueba East US |
| App Service plan | Crear nuevo: plan-max-week2-free |
| Pricing plan | Free F1, mediante Change size/Cambiar tamaño |
| Application Insights, si aparece | Desactivado para esta prueba |

En Review + create, verifica específicamente Free F1 antes de Create. Si F1 no está disponible por región, cuota o política, prueba una región autorizada. No sustituyas por Basic/B1 o Premium, que tienen costo. No elijas Web App + Database.

Espera a que termine la creación y pulsa Go to resource. Es el recurso Web App, distinto del plan que define capacidad y precio.

## 9. Configurar arranque y variables — Azure Portal

Dentro de tu Web App, abre Settings > Configuration > General settings (los nombres pueden aparecer traducidos). En Startup Command pega:

```text
python -m uvicorn main:app --host 0.0.0.0 --port 8000
```

Guarda/Apply. Para Python 3.12, FastAPI requiere configurar el arranque. Mantén Always On desactivado en F1 y HTTPS Only activado.

Abre Settings > Environment variables > App settings (en interfaces anteriores, Configuration > Application settings). Añade y aplica:

| Nombre | Valor |
|---|---|
| GEMINI_API_KEY | Tu clave real de Gemini |
| APP_API_KEY | La misma clave de acceso que generaste |
| GEMINI_MODEL | gemini-2.5-flash-lite |
| SCM_DO_BUILD_DURING_DEPLOYMENT | true |

Elimina GROQ_API_KEY y GROQ_MODEL de Azure si estaban configuradas. La última variable hace que Azure instale requirements.txt al desplegar. .env no se enviará a Azure; aquí configuras sus equivalentes. Los cambios pueden reiniciar la aplicación.

## 10. Preparar Azure CLI — Terminal de Codespaces

Detén el servidor local con Ctrl+C. Si el entorno .venv está activado, usa deactivate; si no, omite ese comando. En la misma terminal:

```bash
deactivate
az version
```

Si az ya funciona, sigue. Solo si aparece command not found, instala la CLI con el instalador oficial para Debian/Ubuntu:

```bash
curl -fL https://aka.ms/InstallAzureCLIDeb -o /tmp/install-azure-cli.sh
sudo bash /tmp/install-azure-cli.sh
az version
```

No avances si la instalación falla. Estos comandos se ejecutan en Codespaces, no en Terminal Mac.

## 11. Conectar Codespaces con Azure — Terminal y navegador

```bash
az login --use-device-code
```

La terminal mostrará una URL y un código. Abre la URL indicada, introduce el código e inicia sesión con la cuenta de tu suscripción Azure. No compartas ese código. Si el flujo pide elegir suscripción, selecciona la de esta guía.

```bash
az account list --query "[].{Nombre:name,ID:id}" --output table
az account set --subscription "PEGA_EL_ID_DE_TU_SUSCRIPCION"
az account show --query "{Nombre:name,ID:id}" --output table
```

Reemplaza el texto de ejemplo por el ID real listado. El último comando confirma la cuenta de destino.

## 12. Empaquetar únicamente la API — Terminal de Codespaces

```bash
cd /workspaces/max1102-pipeline/api
python - <<'PY'
from zipfile import ZipFile, ZIP_DEFLATED
with ZipFile('/tmp/max-week2-api.zip', 'w', ZIP_DEFLATED) as archive:
    for filename in ('main.py', 'requirements.txt'):
        archive.write(filename, filename)
print('ZIP listo: /tmp/max-week2-api.zip')
PY
```

El ZIP contiene main.py y requirements.txt en su raíz. No incluye api/ como carpeta superior, .env, .venv, datos ni Airflow.

## 13. Desplegar — Terminal de Codespaces

Reemplaza el nombre de ejemplo por el nombre exacto que creaste en Azure:

```bash
AZURE_RESOURCE_GROUP="rg-max-week2-api"
AZURE_WEBAPP_NAME="maxweek2-gustavo-58341"

az webapp deploy \
  --resource-group "$AZURE_RESOURCE_GROUP" \
  --name "$AZURE_WEBAPP_NAME" \
  --src-path /tmp/max-week2-api.zip \
  --type zip
```

Espera a que finalice y comprueba que no haya errores de construcción o despliegue. Azure instalará las dependencias y ejecutará el comando de arranque. Si ya existía el despliegue con Groq, se actualiza a Gemini en la misma aplicación.

## 14. Probar desde Azure — Navegador

Azure Portal > tu Web App > Overview > copia Default domain/Dominio predeterminado o pulsa Browse. Usa ese dominio real, que puede incluir un sufijo generado por Azure.

Abre https://TU-DOMINIO/health y luego https://TU-DOMINIO/docs. Repite Authorize, Try it out y Execute como en el paso 7; en la respuesta debe aparecer model: gemini-2.5-flash-lite. En esta ocasión la petición llega a Azure y desde allí llama a Gemini.

Para comprobarlo, abre la URL de Azure después de detener tu Codespace: la API Azure debe poder responder sin el Codespace, sujeto a suscripción y cuotas activas.

## 15. Pruebas y diagnóstico — Navegador y Azure Portal

| Prueba | Resultado esperado |
|---|---|
| Claim válido y clave correcta | 200, resumen fiel al monto, estado y fecha |
| Clave incorrecta/ausente | 401 |
| Monto negativo, mayor de 50000, fecha imposible o estado desconocido | 422 |
| Campo extra como member_name | 422 |
| Falta una clave en configuración del servidor | 503 |
| Gemini supera su cuota | 429: revisa Usage/Rate limits del proyecto; puede ser por minuto, por día o cuota cero |
| Gemini no responde a tiempo | 504 |
| Error del proveedor, modelo no disponible o respuesta incompleta | 502 |

Para probar 422, conserva una clave válida. Un 401 corresponde a tu APP_API_KEY. Un 502 con rechazo de acceso corresponde a GEMINI_API_KEY o permisos del proyecto; un 502 de modelo requiere revisar GEMINI_MODEL. Para mantener la práctica gratis, no habilites facturación para resolver un 429. Una cuota de cero no siempre se soluciona esperando. Si debes cambiar de modelo, comprueba primero su nivel gratuito y la cuota disponible, y actualízalo tanto en .env como en Azure. Estas comprobaciones no sustituyen Great Expectations: Pydantic valida la petición HTTP, y GX valida tus datasets del pipeline.

Si aparece una página predeterminada o error de arranque, revisa Startup Command, SCM_DO_BUILD_DURING_DEPLOYMENT, dependencias y resultado del despliegue. En Azure Portal abre Deployment Center > Logs para la construcción. Para ejecución, App Service logs > habilita Application logging en Filesystem y abre Log stream. No habilites Application Insights para resolver esta prueba. F1 puede arrancar lentamente tras inactividad; también tiene cuota de CPU. No cambies a un plan de pago para solucionar un timeout.

## 16. Guardar código y evidencia — Codespaces/GitHub

Antes de detener Codespaces, vuelve a la raíz y guarda únicamente el código y la guía:

```bash
cd /workspaces/max1102-pipeline
git status --short
git add api/main.py api/requirements.txt api/.env.example api/test_api.py api/requirements-dev.txt GUIA_AZURE_WEEK2.md .gitignore
git diff --cached --name-only
```

Comprueba que .env no figure en la lista. Si ya había otros archivos preparados para commit, revísalos también. Después:

```bash
git commit -m "Use Gemini for authenticated claim summary API"
git push
```

Comprueba que .env no figure entre los archivos a confirmar. Guarda evidencia de un HTTP 200 y de 401/422, sin capturar claves. Eso demuestra creación, configuración, despliegue y pruebas. El código no se ha desplegado desde esta guía: necesitas ejecutar los pasos en tus cuentas. Pasaron 25 pruebas locales de autenticación, validación, errores y respuestas incompletas. Una prueba ejercita el SDK real de Google con HTTP interceptado localmente. No se realizó una llamada real a Gemini ni un despliegue Azure desde el entorno de creación.

## 17. Terminar la práctica — Azure Portal y GitHub

Cuando hayas guardado el código y la evidencia, en Azure Portal abre Resource groups > rg-max-week2-api > Delete resource group. Revisa que solo contenga los recursos de esta práctica, escribe el nombre solicitado y confirma. Esto elimina la aplicación y su plan. Borrar este grupo dedicado evita dejar recursos de la práctica activos. Si solo quieres pausar la app puedes usar Stop, pero eso no elimina los recursos y los planes de pago pueden seguir facturándose.

Luego, GitHub > Codespaces > menú de tu Codespace > Stop codespace. Esto detiene el cómputo; su almacenamiento persiste. Si ya guardaste todo en GitHub y quieres eliminarlo también, usa Delete codespace. Al eliminar Azure, su URL dejará de responder; el código permanece en GitHub.

## Pruebas automatizadas opcionales — Terminal de Codespaces

Dentro de api/, con .venv activado:

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q test_api.py
```

Son 25 pruebas con respuestas simuladas: no necesitan claves reales ni consumen la cuota de Google. Puede aparecer una advertencia de compatibilidad futura de Starlette/TestClient; no es un fallo de la API.

## Fuentes oficiales consultadas el 8 de octubre de 2026

- https://azure.microsoft.com/en-us/free/students/
- https://azure.microsoft.com/en-us/free/free-account-faq/
- https://azure.microsoft.com/en-us/pricing/details/app-service/linux/
- https://learn.microsoft.com/en-us/azure/app-service/configure-language-python
- https://learn.microsoft.com/en-us/azure/app-service/deploy-zip
- https://learn.microsoft.com/en-us/cli/azure/webapp
- https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-linux
- https://ai.google.dev/gemini-api/docs/api-key
- https://ai.google.dev/gemini-api/docs/rate-limits
- https://ai.google.dev/gemini-api/docs/pricing
- https://ai.google.dev/gemini-api/docs/billing
- https://googleapis.github.io/python-genai/

Esta API es una práctica con datos sintéticos y una clave compartida. Para un servicio empresarial, la autenticación, manejo de datos, monitoreo y capacidad deben ajustarse a sus requisitos.
