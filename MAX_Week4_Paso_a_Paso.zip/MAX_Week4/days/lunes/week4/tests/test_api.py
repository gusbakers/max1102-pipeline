import asyncio
from types import SimpleNamespace

import httpx
import pytest
from fastapi.testclient import TestClient
from api import main as api

PAYLOAD = {
    'claim_id': 'DEMO_001', 'claim_amount': '120.50',
    'claim_status': 'PAID', 'service_date': '2025-12-15',
}
HEADERS = {'X-API-Key': 'test-only-not-a-real-key'}

@pytest.fixture(autouse=True)
def isolated_env(monkeypatch):
    monkeypatch.setenv('APP_API_KEY', HEADERS['X-API-Key'])
    monkeypatch.setenv('GEMINI_API_KEY', 'mock-key-never-sent')
    def blocked(*args, **kwargs):
        raise AssertionError('A test attempted a real Gemini call')
    monkeypatch.setattr(api.genai, 'Client', blocked)

@pytest.fixture
def client():
    with TestClient(api.app) as c:
        yield c

def test_health_does_not_call_llm(client):
    r = client.get('/health')
    assert r.status_code == 200
    assert r.json() == {'status': 'ok'}

@pytest.mark.parametrize('headers', [{}, {'X-API-Key': 'incorrect'}])
def test_authentication_is_required(client, headers):
    assert client.post('/claims/llm-summary', json=PAYLOAD, headers=headers).status_code == 401

@pytest.mark.parametrize('change', [
    {'claim_amount': -1}, {'claim_amount': 50001},
    {'claim_status': 'UNKNOWN'}, {'service_date': '2025-99-99'},
    {'patient_name': 'not-allowed'},
])
def test_invalid_claim_is_rejected_before_llm(client, change):
    r = client.post('/claims/llm-summary', json=PAYLOAD | change, headers=HEADERS)
    assert r.status_code == 422

def test_missing_server_key(client, monkeypatch):
    monkeypatch.delenv('APP_API_KEY')
    assert client.post('/claims/llm-summary', json=PAYLOAD, headers=HEADERS).status_code == 503

def test_missing_provider_key(client, monkeypatch):
    monkeypatch.delenv('GEMINI_API_KEY')
    assert client.post('/claims/llm-summary', json=PAYLOAD, headers=HEADERS).status_code == 503

def fake_provider(monkeypatch, result=None, failure=None):
    class FakeAsyncClient:
        async def __aenter__(self):
            return self
        async def __aexit__(self, *args):
            return False
        @property
        def models(self):
            return self
        async def generate_content(self, **kwargs):
            assert PAYLOAD['claim_id'] not in kwargs['contents']
            if failure:
                raise failure
            return result
    monkeypatch.setattr(api.genai, 'Client', lambda **kwargs: SimpleNamespace(aio=FakeAsyncClient()))

def test_summary_returns_provider_result(client, monkeypatch):
    result = SimpleNamespace(
        candidates=[SimpleNamespace(finish_reason=api.types.FinishReason.STOP)],
        text='Claim pagado por 120.50, con fecha de servicio 2025-12-15.',
    )
    fake_provider(monkeypatch, result=result)
    r = client.post('/claims/llm-summary', json=PAYLOAD, headers=HEADERS)
    assert r.status_code == 200
    assert r.json()['claim_id'] == PAYLOAD['claim_id']
    assert r.json()['summary'] == result.text

def test_provider_timeout_is_controlled(client, monkeypatch):
    fake_provider(monkeypatch, failure=httpx.ReadTimeout('test timeout'))
    assert client.post('/claims/llm-summary', json=PAYLOAD, headers=HEADERS).status_code == 504

def test_empty_provider_response_is_rejected(client, monkeypatch):
    fake_provider(monkeypatch, result=SimpleNamespace(candidates=[]))
    assert client.post('/claims/llm-summary', json=PAYLOAD, headers=HEADERS).status_code == 502
