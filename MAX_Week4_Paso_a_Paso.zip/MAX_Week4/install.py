"""Copy the selected day into the current repository with local backups."""
import argparse
import datetime
from pathlib import Path
import shutil

p = argparse.ArgumentParser()
p.add_argument('day', choices=['lunes','martes','miercoles','jueves','viernes'])
args = p.parse_args()
root = Path.cwd()
if not (root / '.git').exists() or not (root / 'api/main.py').exists():
    raise SystemExit('Run from the repository root containing .git and api/main.py.')
package = Path(__file__).resolve().parent
ignore = root / '.gitignore'
text = ignore.read_text() if ignore.exists() else ''
extra = '\n# MAX Week 4 local-only files\nMAX_Week4/\n.week4-private/\n.week4-backups/\n.venv-week4/\nrelease/\n**/.terraform/\n*.tfstate*\n*.tfplan\n*.tfvars\n*.tfvars.json\ninfra/**/generated*.tf\ninfra/**/plan*.json\n'
if '# MAX Week 4 local-only files' not in text:
    ignore.write_text(text + extra)
backup = root / '.week4-backups' / (datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f') + '-' + args.day)
for src in sorted((package / 'days' / args.day).rglob('*')):
    if not src.is_file():
        continue
    rel = src.relative_to(package / 'days' / args.day)
    dst = root / rel
    if dst.exists():
        previous = backup / rel
        previous.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(dst, previous)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    print('Installed:', rel)
if args.day == 'martes':
    main = root / 'api/main.py'
    content = main.read_text()
    if '# Week4 observability' not in content:
        anchor = 'api_key_header = APIKeyHeader'
        if anchor not in content:
            raise SystemExit('main.py has changed: add the observability import manually as described in the guide.')
        old = backup / 'api/main.py'
        old.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(main, old)
        addition = """# Week4 observability
try:
    from .week4_observability import install as install_observability
except ImportError:
    from week4_observability import install as install_observability
install_observability(app)

"""
        main.write_text(content.replace(anchor, addition + anchor, 1))
        print('Updated: api/main.py (version endpoint and request logs)')
print('Review: git diff; git status --short. Backups:', backup)
