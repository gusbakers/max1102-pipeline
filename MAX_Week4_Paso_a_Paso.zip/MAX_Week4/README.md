# MAX Week 4 - archivos por día

Explicación principal: paso a paso en el chat. GUIA_Semana4.md conserva una copia
ampliada para consultar las rutas y recuperar los comandos.

1. Subir MAX_Week4_Paso_a_Paso.zip a la raíz del repositorio en Codespaces.
2. Extraer: python3 -m zipfile -e MAX_Week4_Paso_a_Paso.zip .
3. Desde la raíz del repo: python3 MAX_Week4/install.py lunes.
4. Continuar con martes, miercoles, jueves y viernes cuando corresponda.

install.py conserva backups locales de los archivos sustituidos y añade
exclusiones a .gitignore. No hace commit, push, login ni despliegues por sí solo.
No incluye secretos ni copias de datos. Para lunes/martes necesita el API actual
de gusbakers/max1102-pipeline. No sustituye los notebooks Databricks por versiones
inventadas: debes exportar y revisar las que funcionan en tu workspace.

Validación local del paquete:

- 13 pruebas API aprobadas con los requirements del repositorio revisado.
- Instalación por día comprobada en una copia temporal.
- Workflows YAML parseados y Python compilado.
- ZIP de despliegue limitado a main.py, observability, requirements y metadata.
- Generación HCL formateada con Terraform 1.13.5.
- Control de importación acepta no-op y rechaza update/replacement.

No se ejecutaron despliegues cloud, planes autenticados ni Docker en este
entorno. Su validación se realiza en tus cuentas siguiendo la guía. El check
de DAG usa la imagen y el test existentes y se ejecutará en GitHub.

Alcance: CD de API y notebooks; Airflow continúa como laboratorio en Codespaces.
Infraestructura: el inventario real y los .tf generados/revisados son necesarios
para dar por completada la adopción. Los templates no son un despliegue ya hecho.
